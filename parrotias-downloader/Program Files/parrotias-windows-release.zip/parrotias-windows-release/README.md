# parrotias-windows

## In Progress

### Update: 1st June, 2023

- Fix the sizing issue
- Add zoom functionalities

Still in Progress
<img width="935" alt="Screenshot 2023-05-24 at 10 19 14" src="https://github.com/Steelzen/parrotias-windows/assets/94742043/c9d45600-a491-4fc7-8c1e-c584a3fcdbce">
